package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/*import jdk.nashorn.internal.ir.RuntimeNode.Request;*/


public class TestDBBean {
	// �̱���
	private static TestDBBean instance = new TestDBBean();
	private TestDBBean() {
		
	}
	
	public static TestDBBean getInstance() {
		return instance;
	}
	// ��Ŭ�� end.
	
	// �����ͺ��̽� ���� ��������
	public static Connection getConnection() {
		Connection conn = null;
		try {
			String jdbcUrl = "jdbc:oracle:thin:@localhost:1521:orcl";
			String dbId = "scott";
			String dbpwd = "tiger";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(jdbcUrl, dbId, dbpwd);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	// Close
	public void close (Connection conn, ResultSet rs, PreparedStatement pstmt) {
		if(conn!=null) try {conn.close();} catch(SQLException ex) {}
		if(rs!=null) try {rs.close();} catch(SQLException ex) {}
		if(pstmt!=null) try {pstmt.close();} catch (SQLException e) {}
	}
	
	// ȸ������ (�߰�) �޼ҵ�
	public void insertUser(TestDataBean user) {
		String sql="";
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int number=0;
		try {
			pstmt = conn.prepareStatement("select TestSer.nextval from dual");
			rs = pstmt.executeQuery();
			if (rs.next())
				number = rs.getInt(1) + 1;
			else number = 1;
			
			sql = "insert into Testlist(num, email, name, pwd, tel, birth, cdate, ip)";
			sql += "values(?,?,?,?,?,?, sysdate, ?)";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, number);
			pstmt.setString(2, user.getEmail());
			pstmt.setString(3, user.getName());
			pstmt.setString(4, user.getPwd());
			pstmt.setString(5, user.getTel());
			pstmt.setString(6, user.getBirth());
			pstmt.setString(7, user.getIp());
			
			
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(conn, rs, pstmt);
		}
		
	}
	
	// ȸ�� �� �޼ҵ�
	public int getUserCount() throws SQLException {
		int x = 0;
		String sql = "SELECT nvl(count(*),0) FROM Testlist";
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int number = 0;
		
		try {
		pstmt = conn.prepareStatement(sql);
	
		
		rs = pstmt.executeQuery();
		if (rs.next()) { x = rs.getInt(1); }
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			close(conn, rs, pstmt);
		}
		
		return x;
	}
	
	// ȸ������Ʈ ������ �޼ҵ�?
	public List getUsers(int startRow, int endRow) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List usList = null;
		String sql = "";
		try {
			conn = getConnection();
			sql = "select * from (select rownum rnum, a.* from (select num, email, name, pwd, tel, birth, cdate, ip from Testlist)"
					+ " a) where rnum between ? and ? order by cdate desc";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				usList = new ArrayList();
			
				do {
					TestDataBean user = new TestDataBean();
					user.setNum(rs.getInt("num"));
					user.setEmail(rs.getString("email"));
					user.setName(rs.getString("name"));
					user.setPwd(rs.getString("pwd"));
					user.setTel(rs.getString("tel"));
					user.setBirth(rs.getString("birth"));
					user.setCdate(rs.getTimestamp("cdate"));
					user.setIp(rs.getString("ip"));
					usList.add(user);
				} while (rs.next()); 
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			close(conn, rs, pstmt);
		}
		return usList;
		
	}
	
	// ȸ�� �����Ҷ� ���� �ҷ�����
	public TestDataBean getUser(String email, String pwd) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		TestDataBean user = null;
		String sql = "";
		try {
			conn = getConnection();
			sql="select * from Testlist where email = ? and pwd = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, email);
			pstmt.setString(2, pwd);
			rs=pstmt.executeQuery();
			
			user = new TestDataBean();
			if(rs.next()) {
				user.setNum(rs.getInt("num"));
				user.setEmail(rs.getString("email"));
				user.setName(rs.getString("name"));
				user.setPwd(rs.getString("pwd"));
				user.setTel(rs.getString("tel"));
				user.setBirth(rs.getString("birth"));
				user.setCdate(rs.getTimestamp("cdate"));
				user.setIp(rs.getString("ip"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(conn, rs, pstmt);
		}
	
		return user;
		
	}
	
	 // �α��ν� ���̵�, ��й�ȣ üũ �޼���
    // ���̵�, ��й�ȣ�� ���ڷ� �޴´�.
    public int loginCheck(String email, String pwd) 
    {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
 
        String dbPW = ""; // db���� ���� ��й�ȣ�� ���� ����
        int x = -1;
 
        try {
            // ���� - ���� �Էµ� ���̵�� DB���� ��й�ȣ�� ��ȸ�Ѵ�.
            StringBuffer query = new StringBuffer();
            query.append("select pwd from Testlist where email=?");
 
            conn = getConnection();
            pstmt = conn.prepareStatement(query.toString());
            pstmt.setString(1, email);
            rs = pstmt.executeQuery();
 
            if (rs.next()) // �Էµ� ���̵� �ش��ϴ� ��� �������
            {
                dbPW = rs.getString("pwd"); // ����� ������ �ִ´�.
 
                if (dbPW.equals(pwd)) 
                    x = 1; // �Ѱܹ��� ����� ������ ��� ��. ������ ��������
                else                  
                    x = 0; // DB�� ��й�ȣ�� �Է¹��� ��й�ȣ �ٸ�, ��������
                
            } else {
                x = -1; // �ش� ���̵� ���� ���
            }
 
            return x;
 
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        } finally {
        	 close(conn, null, pstmt);
        }
    } // end loginCheck()

	
    
    public int deleteUser (String email, String pwd) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "delete from Testlist where email=? and pwd=?";
		int x = -1;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, email);
			pstmt.setString(2, pwd);
			x=pstmt.executeUpdate();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			close(conn, rs, pstmt);
		}
		return x;
	}
    
    public int updateUser (TestDataBean user) {
		String sql ="";
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		int chk= 0; // int ���� �ϳ� ����.
		/*ResultSet rs = null; <- �����.(����)*/
		
		try {
			conn = getConnection();
			sql = "update Testlist set email=?, name=?, pwd=?, tel=?, birth=? where num=?";
			pstmt = conn.prepareStatement(sql);
		
			pstmt.setString(1, user.getEmail());
			pstmt.setString(2, user.getName());
			pstmt.setString(3, user.getPwd());
			pstmt.setString(4, user.getTel());
			pstmt.setString(5, user.getBirth());
			pstmt.setInt(6, user.getNum());
			
			chk = pstmt.executeUpdate(); //�÷��� ������Ʈ�� �Ǿ����� ���ڸ� ��ȯ
			/*pstmt.executeUpdate(); <- �����.*/

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(conn, null, pstmt);
		}
		return chk;
		
	}
    
    // ������..?
    /*public boolean admin_login(String admin_id,String admin_pass){
    	Connection conn = null;
    	PreparedStatement pstmt = null;
    	ResultSet rs = null;
    	
    	boolean b = false;
		
		try {
			String sql = "select * from userlist where email = 'admin' and pwd = 9005242";
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, admin_id);
			pstmt.setString(2, admin_pass);
			rs = pstmt.executeQuery();
			b=rs.next();
		} catch (Exception e) {
			System.out.println("admin_login err : " + e);
		} finally {
			try {
				if(rs!=null)rs.close();
				if(pstmt!=null)pstmt.close();
				if(conn!=null)conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				close(conn, rs, pstmt);
			}
		}
		return b;
	}*/
}
