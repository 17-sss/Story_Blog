## TODO List
### 빌드 및 구조 개선
* npm 지원
* bower 지원
* grunt 빌드 전환
* test 코드 공개
* 소스코드 구조 개선

### 다국어 개선
* 다국어 샘플 추가

### 디펜던시 개선
* 에디팅코어 모듈 교체
* jindo 디펜던시 제거
* 라이브러리 Adapter 구현 (jindo/jQuery 선택 사용 가능하도록)
